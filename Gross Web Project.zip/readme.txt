Charles Gross
INFS2150 Web Project Assignment

Information regarding the source of images can be found in the file LicenseInfo.txt.

Advanced requirement(s):
1.) Javascript Photo slideshow on index (customized slightly from the one provided on blackboard)
2.) Javascript form validation and form submission alert window.

Extra Credit:
I chose not to implement the extra credit requirements as I didn't use any of my extra lives.